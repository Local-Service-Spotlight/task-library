# Wichita — Google Ads Workshop

Paid-ads + measurement bundle for a local-service Google Ads workshop. Anchored on google-ads-analyzer.

10 skills from the Local Service Spotlight Task Library (library updated September 22, 2026).

This download is a dated snapshot. Open START-HERE.md for one useful first job. A status is a contributor claim, not proof of installation or completed client work.

## Skills

- **Google Ads Analyzer (weekly MAA)** (`google-ads-analyzer`) — complete
- **Stage 1: Plumbing (FB Ads, Google Ads, Analytics)** (`stage-1-plumbing-fb-ads-google-ads-analytics`) — complete
- **Stage 2: Goals (mission, 90-day goals, CPA/ROAS, budget)** (`stage-2-goals-mission-90-day-goals-cpa-roas-budget`) — complete
- **MAA cycle (Metrics, Analysis, Action)** (`maa-cycle-metrics-analysis-action`) — complete
- **Submit weekly MAA report every Friday** (`submit-weekly-maa-report-every-friday`) — needs-work
- **Set Up GA4 With Internal Traffic Filtering** (`set-up-ga4-with-internal-traffic-filtering`) — gap
- **Set Up Call Tracking for Phone Conversions** (`set-up-call-tracking-for-phone-conversions`) — needs-work
- **Install Google Tag Manager Container** (`install-google-tag-manager-container`) — gap
- **Analyze cost per result and engagement** (`analyze-cost-per-result-and-engagement`) — complete
- **Kill underperformers, scale winners** (`kill-underperformers-scale-winners`) — complete
