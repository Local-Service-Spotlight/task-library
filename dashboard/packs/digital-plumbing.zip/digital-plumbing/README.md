# Digital Plumbing

The foundational setup category (tracking, DNS, GBP, schema).

29 skills from the Local Service Spotlight Task Library (library updated September 10, 2026).

This download is a dated snapshot. Open START-HERE.md for one useful first job. A status is a contributor claim, not proof of installation or completed client work.

## Skills

- **Add Click-to-Call Links for Mobile** (`add-click-to-call-links-for-mobile`) — needs-work
- **Add Schema Markup (Person/LocalBusiness)** (`add-schema-markup-person-localbusiness`) — needs-work
- **Claim and Brand Facebook Page** (`claim-and-brand-facebook-page`) — needs-work
- **Configure HTTPS With No Mixed Content** (`configure-https-with-no-mixed-content`) — needs-work
- **Configure SPF/DKIM/DMARC for Deliverability** (`configure-spf-dkim-dmarc-for-deliverability`) — needs-work
- **Convert Instagram to Professional Account** (`convert-instagram-to-professional-account`) — needs-work
- **Create Clear Conversion Path** (`create-clear-conversion-path`) — needs-work
- **Create LinkedIn Page Matching Business Entity** (`create-linkedin-page-matching-business-entity`) — needs-work
- **Create XML Sitemap and Reference in robots.txt** (`create-xml-sitemap-and-reference-in-robots-txt`) — needs-work
- **Ensure NAP Consistency Across Platforms** (`ensure-nap-consistency-across-platforms`) — needs-work
- **Ensure Proper DNS Records** (`ensure-proper-dns-records`) — needs-work
- **Ensure Robots Meta Not Blocking Indexing** (`ensure-robots-meta-not-blocking-indexing`) — needs-work
- **Ensure Site Loads Under 3 Seconds on Mobile** (`ensure-site-loads-under-3-seconds-on-mobile`) — needs-work
- **Ensure Working Contact Form Delivers Notifications** (`ensure-working-contact-form-delivers-notifications`) — needs-work
- **Install Google Tag Manager Container** (`install-google-tag-manager-container`) — gap
- **Install Meta Pixel With Standard Events** (`install-meta-pixel-with-standard-events`) — gap
- **Set Correct Business Categories** (`set-correct-business-categories`) — needs-work
- **Set Favicon** (`set-favicon`) — needs-work
- **Set Up Call Tracking for Phone Conversions** (`set-up-call-tracking-for-phone-conversions`) — needs-work
- **Set Up Consistent Headshots and Bios Across Profiles** (`set-up-consistent-headshots-and-bios-across-profiles`) — needs-work
- **Set Up GA4 With Internal Traffic Filtering** (`set-up-ga4-with-internal-traffic-filtering`) — gap
- **Set Up Professional Email on Domain** (`set-up-professional-email-on-domain`) — needs-work
- **Set Up YouTube Channel With Proper Branding** (`set-up-youtube-channel-with-proper-branding`) — needs-work
- **Upload Real Photos and Set Business Hours** (`upload-real-photos-and-set-business-hours`) — needs-work
- **Verify Domain Ownership and Registrar Access** (`verify-domain-ownership-and-registrar-access`) — needs-work
- **Verify Google Business Profile** (`verify-google-business-profile`) — complete
- **Verify Google Search Console and Connect to GA4** (`verify-google-search-console-and-connect-to-ga4`) — needs-work
- **Write Proper Title Tags and Meta Descriptions** (`write-proper-title-tags-and-meta-descriptions`) — needs-work
- **Build an agency website for a vertical** (`build-agency-website-for-vertical`) — needs-work
