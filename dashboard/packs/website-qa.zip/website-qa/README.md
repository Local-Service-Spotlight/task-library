# Website QA Audit

Guides for checking website quality.

39 skills from the Local Service Spotlight Task Library (library updated September 22, 2026).

This download is a dated snapshot. Open START-HERE.md for one useful first job. A status is a contributor claim, not proof of installation or completed client work.

## Skills

- **Audit internal links between all blog posts** (`audit-internal-links-between-all-blog-posts`) — complete
- **Check all CTA buttons lead to correct destinations** (`check-all-cta-buttons-lead-to-correct-destinations`) — needs-work
- **Check each homepage section includes relevant image** (`check-each-homepage-section-includes-relevant-image`) — complete
- **Check favicon is set** (`check-favicon-is-set`) — needs-work
- **Check for broken links** (`check-for-broken-links`) — complete
- **Check lead magnet section has visual mockup** (`check-lead-magnet-section-has-visual-mockup`) — complete
- **Check meta description under 160 chars** (`check-meta-description-under-160-chars`) — complete
- **Check schema connects to all verified profiles** (`check-schema-connects-to-all-verified-profiles`) — complete
- **Check SEO title under 60 chars with focus keyword** (`check-seo-title-under-60-chars-with-focus-keyword`) — complete
- **Check social profiles linked and prominent** (`check-social-profiles-linked-and-prominent`) — complete
- **Ensure no stock images used** (`ensure-no-stock-images-used`) — complete
- **Ensure no text-only sections spanning full viewport** (`ensure-no-text-only-sections-spanning-full-viewport`) — complete
- **Ensure robots meta not blocking indexing** (`ensure-robots-meta-not-blocking-indexing--qa-audit`) — complete
- **Test mobile load time under 3 seconds** (`test-mobile-load-time-under-3-seconds`) — complete
- **Verify achievements are evidenced, not just claimed** (`verify-achievements-are-evidenced-not-just-claimed`) — complete
- **Verify all images have descriptive alt text** (`verify-all-images-have-descriptive-alt-text`) — complete
- **Verify all pages written in first person** (`verify-all-pages-written-in-first-person`) — complete
- **Verify at least one video embed on homepage** (`verify-at-least-one-video-embed-on-homepage`) — complete
- **Verify email opt-in form exists and works** (`verify-email-opt-in-form-exists-and-works`) — complete
- **Verify entity linking follows decision tree** (`verify-entity-linking-follows-decision-tree`) — complete
- **Verify featured images unique per blog post** (`verify-featured-images-unique-per-blog-post`) — complete
- **Verify footer includes social links and secondary nav** (`verify-footer-includes-social-links-and-secondary-nav`) — complete
- **Verify GA4 configured with internal traffic filtered** (`verify-ga4-configured-with-internal-traffic-filtered`) — complete
- **Verify Google Business Profile is verified** (`verify-google-business-profile-is-verified`) — complete
- **Verify GTM installed and firing on every page** (`verify-gtm-installed-and-firing-on-every-page`) — complete
- **Verify hero section contains real photo of person** (`verify-hero-section-contains-real-photo-of-person`) — complete
- **Verify HTTPS with no mixed content** (`verify-https-with-no-mixed-content`) — complete
- **Verify Meta pixel installed with lead events** (`verify-meta-pixel-installed-with-lead-events`) — complete
- **Verify minimum 5 distinct images on homepage** (`verify-minimum-5-distinct-images-on-homepage`) — complete
- **Verify Person schema with sameAs links** (`verify-person-schema-with-sameas-links`) — needs-work
- **Verify Rank Math score above 70 on every page** (`verify-rank-math-score-above-70-on-every-page`) — complete
- **Verify social proof photos present** (`verify-social-proof-photos-present`) — complete
- **Verify testimonials include headshots with attribution** (`verify-testimonials-include-headshots-with-attribution`) — complete
- **Verify testimonials with full attribution** (`verify-testimonials-with-full-attribution`) — complete
- **Verify WordPress author set to site owner name** (`verify-wordpress-author-set-to-site-owner-name`) — complete
- **Verify XML sitemap exists and in robots.txt** (`verify-xml-sitemap-exists-and-in-robotstxt`) — complete
- **Audit a local-service website** (`audit-local-service-website`) — needs-work
- **Run weekly client SEO audits** (`run-weekly-client-seo-audits`) — needs-work
- **Add homepage blog-card thumbnails** (`add-homepage-blog-card-thumbnails`) — needs-work
