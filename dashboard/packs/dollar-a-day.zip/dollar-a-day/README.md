# Dollar-a-Day Campaigns

Every Dollar-a-Day campaign skill.

18 skills from the Local Service Spotlight Task Library (library updated September 15, 2026).

This download is a dated snapshot. Open START-HERE.md for one useful first job. A status is a contributor claim, not proof of installation or completed client work.

## Skills

- **Analyze cost per result and engagement** (`analyze-cost-per-result-and-engagement`) — complete
- **Boost one-minute videos for personal branding** (`boost-one-minute-videos-for-personal-branding`) — needs-work
- **Build audience layers** (`build-audience-layers`) — complete
- **Create Facebook/Instagram campaigns with location targeting** (`create-facebook-instagram-campaigns-with-location-targeting`) — needs-work
- **Create YouTube campaigns using ADUCATE model** (`create-youtube-campaigns-using-aducate-model`) — needs-work
- **Execute switch boosts to new audiences** (`execute-switch-boosts-to-new-audiences`) — needs-work
- **Identify signals worth amplifying** (`identify-signals-worth-amplifying`) — complete
- **Kill underperforming ads** (`kill-underperforming-ads`) — complete
- **Run multiple simultaneous tests** (`run-multiple-simultaneous-tests`) — complete
- **Run Twitter/X promotion for thought leader threads** (`run-twitter-x-promotion-for-thought-leader-threads`) — needs-work
- **Scale winners by increasing budget gradually** (`scale-winners-by-increasing-budget-gradually`) — complete
- **Sequence content from awareness to conversion** (`sequence-content-from-awareness-to-conversion`) — needs-work
- **Set $1/day budget per ad set** (`set-1-day-budget-per-ad-set`) — complete
- **Set up digital plumbing (pixels, tracking)** (`set-up-digital-plumbing-pixels-tracking`) — complete
- **Set up Meta Business Manager and Public Figure pages** (`set-up-meta-business-manager-and-public-figure-pages`) — needs-work
- **Set up TikTok campaigns** (`set-up-tiktok-campaigns`) — needs-work
- **Use Dollar a Day to influence media coverage** (`use-dollar-a-day-to-influence-media-coverage`) — needs-work
- **Verify prerequisites (product, customers, content)** (`verify-prerequisites-product-customers-content`) — complete
