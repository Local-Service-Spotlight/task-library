# DealCon — Personal Brand

The personal-brand / authority set for a deal-making audience — the live-slug version of the dealcon-10 pack.

12 skills from the Local Service Spotlight Task Library (library updated September 17, 2026).

This download is a dated snapshot. Open START-HERE.md for one useful first job. A status is a contributor claim, not proof of installation or completed client work.

## Skills

- **GCT (Goals, Content, Targeting)** (`gct-goals-content-targeting`) — complete
- **Build personal brand website** (`build-personal-brand-website`) — needs-work
- **Add consistent headshots and bios across profiles** (`add-consistent-headshots-and-bios-across-profiles`) — needs-work
- **Keep speaker bureau profile bookable** (`keep-speaker-bureau-profile-bookable`) — complete
- **Secure guest appearances and speaking engagements** (`secure-guest-appearances-and-speaking-engagements`) — needs-work
- **Build third-party validation** (`build-third-party-validation`) — needs-work
- **Claim and verify Knowledge Panel when it appears** (`claim-and-verify-knowledge-panel-when-it-appears`) — needs-work
- **Implement Person schema with sameAs links** (`implement-person-schema-with-sameas-links`) — needs-work
- **Get featured on podcasts** (`get-featured-on-podcasts`) — needs-work
- **Create collaborative content with industry peers** (`create-collaborative-content-with-industry-peers`) — needs-work
- **Boost one-minute videos for personal branding** (`boost-one-minute-videos-for-personal-branding`) — needs-work
- **Learn, Do, Teach apprentice model** (`learn-do-teach-apprentice-model`) — complete
