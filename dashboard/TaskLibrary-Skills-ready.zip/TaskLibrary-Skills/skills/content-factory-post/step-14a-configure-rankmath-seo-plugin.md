---
name: step-14a-configure-rankmath-seo-plugin
description: "Set a clear search title and page summary. Use Rank Math to find issues without stuffing in extra words."
category: Content Factory — Post
stage: Post
definitive_article: https://localservicespotlight.com/article-guidelines/
status: complete
---

# Step 14a: Configure RankMath SEO plugin

People need a clear reason to open your page from search. This guide helps you set its title and short summary. Start with the real question the page answers, then check that the saved words match it.

**The path:** Real search need → Clear title and summary → Plugin checks → Saved output.

**Use this when:** A prepared WordPress article needs its Rank Math search metadata configured or rechecked.

## Inputs
- The exact page/post, target reader, main question or focus phrase, and current [Goals, Content, and Targeting](https://blitzmetrics.com/gct-business-strategy/) brief.
- An existing working Rank Math setup and permission to edit the page’s fields. Rank Math is a WordPress add-on that checks page text and stores search titles and descriptions. Installation, licensing or paid Content AI is not assumed.
- The current page URL and intended canonical URL, which is the main address search engines should treat as the page’s home. Keep the accepted schema (machine-readable page details) and indexing rules with the brief.
- The editorial acceptance target and latest source draft. The legacy task uses score 70+ as an internal target, not a search-ranking guarantee.

## First-run prompt

> Use the article and agreed search need to set clear Rank Math metadata. Check the installed plugin’s actual tests, fix factual issues, and record the measured score. Keep existing URLs and site settings unless their change is already in scope. Verify saved and served output without promising a Google ranking.

## Steps
1. Read the page and choose the phrase that honestly describes its main need. Avoid expanding to unrelated keywords just to raise a score. Check whether an existing page already owns that topic.
2. Open the Rank Math panel. Set the primary focus keyword. This is the phrase the plugin tests; it is not a command to Google to rank the page.
3. Open General → Edit Snippet where available in the installed editor. Write a clear title and a unique description. Use the source’s under-60 and under-160 character aims as editorial guides, then inspect the displayed width. They are not Google’s fixed limits or a guarantee against truncation.
4. Check that the title, opening and useful headings name the subject naturally. Describe images accurately in alt text rather than inserting a keyword that does not fit what the image shows. Keep an established URL unless a separate URL change is justified and authorized.
5. Review the plugin’s actual tests and fix real omissions. The current beginning-of-content test generally checks the first 10%, not a universal first-paragraph rule. Do not add false facts, padded sections, paid AI, or awkward repetition to satisfy a score.
6. Record the measured score and remaining flags. Compare it with the agreed internal target. If sound editorial choices or parser limits keep it below target, state the exact issue for review instead of looping forever or silently claiming a pass.
7. Inspect the snippet preview, canonical URL and schema type against the actual page. Preserve valid site defaults unless this task includes their correction. Do not change global indexing or plugin settings to improve one score.
8. Save and reopen the fields. After an authorized publication/update, inspect the served title, description and canonical output for this URL. Google may choose different title/snippet text; plugin preview and stored metadata are not proof of a search result or ranking.

## Definition of done (QA checklist)

- [ ] The focus phrase describes the actual page; title and summary are specific and readable.
- [ ] Saved metadata and intended canonical output match the scoped page.
- [ ] The measured score and unresolved flags are recorded honestly against the house target.
- [ ] Alt text and content remain factual; no keyword stuffing, unasked URL change or paid feature was added.
- [ ] Served metadata is checked when published, without claiming Google displayed it or rewarded it.

## Example(s)

**Fictional teaching example — not a measured plugin score.** Maple Cycle uses this sample metadata:

- Focus phrase: `bike repair quote`.
- Title: `Bike repair quote: what to send before your visit`.
- Description: `Learn which photos and details help us plan your bike repair quote, and what we still need to check in the shop.`

The example is useful because the promise matches the article. A photo of Alex at a workbench gets descriptive alt text about that scene, not a string of search terms. If a real run later measures 68, the record must say 68 with the actual flags; it must not borrow an invented “70+ passed” result from this sample.

## Handoff and Content Factory context

The publisher gets the metadata, score evidence and remaining flags. Next is [Review internal links with Link Whisper](https://local-service-spotlight.github.io/task-library/?task=step-14b-run-linkwhisper-for-internal-links#task-step-14b-run-linkwhisper-for-internal-links) where available, followed by [Check the full article checklist](https://local-service-spotlight.github.io/task-library/?task=verify-all-items-on-blog-posting-checklist#task-verify-all-items-on-blog-posting-checklist).

This task serves **Post** in the [Content Factory](https://blitzmetrics.com/content-factory/). Produce supplies the source, Process prepares it, Post places and checks it on the agreed channels, and Promote distributes proven work under its own scope. The task’s actual handoff above defines the next step; list order alone does not create a prerequisite.

## When this runs

Run for a new article and after edits that affect its meaning or metadata. This does not create a rank-monitoring schedule or recurring paid analysis.

## First-run setup and continuity

Use the exact account, source, destination and authority recorded for the job. Carry out publication, messages or repairs already authorized once their required checks pass; do not ask for the same approval again. If an action is outside that scope, finish the authorized work and state the specific remaining need. A login, plugin, or task file does not itself grant new authority.

Keep the latest state, record IDs, revisions and next owner in the project tracker or files. Before a retry, check the current saved/sent/published item to avoid duplicates or overwriting another edit. A model has no guaranteed memory, scheduler or account access just because it is called persistent. A future check needs a configured timer or a named person.

Keep all agent media previews muted with volume zero before playback. If this cannot be verified, use captions, metadata or still frames and state what was not tested. No first-load autoplay is part of these page instructions.

## Write up the real run

For each actual attempt, [write its meta article](https://blitzmetrics.com/meta-article-prompt/) with this exact task, source revision, trigger, work, decisions, evidence, result and next owner. Failed, partial and blocked attempts still get a written record. A private draft is a valid writing outcome; public publication follows the existing scope.

Keep one stable execution ID for the actual task run. Retries, checks and changed artifacts do not add runs. A separately scoped child task may have its own ID linked to its parent; writing the parent’s meta record is part of that same run. The [recipe and meta-article guide](https://localservicespotlight.com/meta-articles/) explains the distinction. Teaching examples below or above are not execution evidence and must not enter the run count.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** Post
- **Importance:** 4/5 `●●●●○` — frequency 4, revenue 4, gating 2 (runs every factory cycle or weekly; creates the asset ads amplify)
- **Suggested previous station:** `step-13-categorize-post-and-add-tags`
- **Suggested next station:** `step-14b-run-linkwhisper-for-internal-links`
These stations are generated neighbors, not verified prerequisites or handoffs. Follow the task’s actual Inputs and Handoff sections.
- **Handoff:** Draft URL or WP post ID, slug, author user ID, featured-image media ID. Promote reads the live URL, not the draft.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- Canonical article: https://localservicespotlight.com/article-guidelines/
- Exact Task Library record: [Step 14a: Configure RankMath SEO plugin](https://local-service-spotlight.github.io/task-library/?task=step-14a-configure-rankmath-seo-plugin#task-step-14a-configure-rankmath-seo-plugin)
- Working writing standard: [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [Rank Math’s current post tests and snippet editor](https://rankmath.com/kb/score-100-in-tests/)
- [Google’s title-link rules](https://developers.google.com/search/docs/appearance/title-link)
- [Google’s snippet rules](https://developers.google.com/search/docs/appearance/snippet)

## Review and evidence still needed

The original contributor status in the header is preserved. It does not certify this proposed rewrite or prove that this account, publication, message, player or check has run. Every worked teaching example is explicitly invented; replace it with actual evidence when documenting a real execution.
- Actual plugin version, editor integration, score and generated metadata require the real site.