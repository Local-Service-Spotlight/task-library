---
name: enhance-existing-articles-before-creating-new-ones
description: "Make your best page more useful before you write a rival to it."
category: SEO & Content Architecture
stage: —
definitive_article: /seo-tree
status: complete
---

# Enhance existing articles before creating new ones

Help readers find what they need on a page you already have. Use this guide to choose where a new fact, video or story fits. The [SEO Tree maps your site](https://blitzmetrics.com/seo-tree/): it helps you pick the right page and link to the next step.

**The path:** New proof → Find the right page → Improve or add a story → Check the result → Pass it on

**Start when:** New material or a content request may overlap a topic the site already covers.

## Inputs

- [Inventory pages and their purpose](https://local-service-spotlight.github.io/task-library/?task=step-1-inventory-content-and-establish-gct-per-page#task-step-1-inventory-content-and-establish-gct-per-page) and [Map actual content roles](https://local-service-spotlight.github.io/task-library/?task=map-content-hierarchically-root-trunk-branches-leaves#task-map-content-hierarchically-root-trunk-branches-leaves) with current topic owners and source revisions.
- The actual new recording, facts, proof or reader question, plus use permissions and [Goals, Content, Targeting: the result, source material and people served](https://blitzmetrics.com/gct-business-strategy/).
- Current page owner, maintained source/builder and the authority for any edit, consolidation or publication.

## Steps

1. Search the maintained inventory, site search and relevant query variants before choosing a new URL. Inspect the actual pages that address the reader’s question. Search results can miss pages; combine them with the source inventory and record any scope limits.
2. Compare the new material with each candidate’s reader, promise, method and proof. Choose the page that owns the same intent, not just the page with a matching keyword. A task recipe, a topic hub, a service offer and a distinct case story can legitimately discuss the same subject.
3. If an owning page exists, prepare a specific enhancement: a clearer definition, corrected method, new source-backed example, current fact or useful visual. Retain relevant proof, author voice, existing media and stable URL/type. Explain what the reader can do better after the change.
4. If the material is a distinct execution, event or case, give it its own supporting story when useful and link it to the owning method. Do not paste a second generic explanation into a competing hub. If no page serves a genuinely distinct core topic, propose a new hub or task recipe with the proper role.
5. When coverage is fragmented, inventory unique value before proposing consolidation. Use [Review duplicate or weak pages](https://local-service-spotlight.github.io/task-library/?task=remove-duplicate-thin-pages#task-remove-duplicate-thin-pages) for the exact keep/merge/remove decision and destination checks. Two pages that mention the same topic are not automatically duplicates, and a merge proposal is not permission to delete or redirect.
6. Apply [Article Guidelines](https://localservicespotlight.com/article-guidelines/) to the proposed page: grade-five opening, clear reader value, useful first-screen visual and evidence-backed claims. Keep relevant named proof and strongest credible sources visible; an attractive rewrite that loses real examples has not improved the page.
7. Save a short decision record: the source material, pages compared, their different reader needs, the chosen page and the reason to improve it or add a distinct story. Record the recipe version you actually used before changing the page. Keep the before/after source and the reviewer’s decision. Spend more time on useful proven material, while leaving room for a real new need.
8. Publish within the authority already given, using the page owner’s supported method. Open the public result without signing in. Check the exact changed text, retained proof, images and links on a phone and desktop. Record what passed and what remains open; a save message alone is not a checked result.
9. Give the checked page, decision record and remaining issues to the named receiving task or worker. Ask for acceptance through an authorized channel, or save the pending request for its existing owner. A sent handoff stays open until the receiver confirms it; do not create a second follow-up clock.

## Definition of done (QA checklist)

Quality assurance (QA) means checking the actual result against its agreed requirements. Follow the [Article Guidelines](https://localservicespotlight.com/article-guidelines/).

- [ ] The decision compares actual intent and evidence, with one maintained owner for the same topic.
- [ ] Distinct task recipes, offers and real supporting stories are not erased just for sharing terms.
- [ ] The proposed improvement preserves unique facts, media and voice and meets current reading and visual standards.
- [ ] One decision record names the compared pages, choice and reason; the starting recipe version, before/after source and separate reviewer decision are saved.
- [ ] When published, the exact changed text, retained proof, images and links pass anonymous phone/desktop checks.
- [ ] The receiving task or worker has the checked output and open issues; acceptance or its pending owner is recorded honestly.
- [ ] For any reader-facing output, the short grade-five opening states the reader’s useful outcome and supporting method or proof. The body delivers that promise; a useful authentic visual appears in the first screen. Retain exact text and quoted reviewer evidence.

## Example(s)

**Fictional teaching example. This is not a client result or proof of a completed run.**

A fictional plumber has a drain-cleaning guide and a new filmed repair. The film adds a useful diagnostic detail, so the team improves that section. The unusual repair also supports a separate dated case story linked to the guide and the real service page. It does not create a second drain-cleaning guide or invent a sales result.

### Checked delivery example

The [Bryce Clark story](https://localservicespotlight.com/bryce-clark-digital-marketing-freedom/) kept its existing address and gained a captioned one-minute video and an audit example. The [AI Builder program proof section](https://localservicespotlight.com/ai-builder-program/#bryce-learning-example) links back to the story. This connects a specific experience to a related offer without creating a second biography.

The [dated review of this enhancement](https://blitzmetrics.com/making-task-guides-easier-to-use/#bryce-proof-followup-20261007) records checked published outputs. The original start time and exact recipe version were not recovered, and the next worker’s acceptance was unconfirmed at that review. This is one historical delivery example; it does not certify this revised recipe, new-user setup or sales results.

## Handoff and Content Factory context

[Create or update the owning recipe](https://local-service-spotlight.github.io/task-library/?task=create-or-update-a-definitive-article#task-create-or-update-a-definitive-article) receives an accepted recipe change; [Place the accepted links](https://local-service-spotlight.github.io/task-library/?task=step-4-create-links-with-proper-anchor-text-and-placement#task-step-4-create-links-with-proper-anchor-text-and-placement) receives its link plan. The content inventory records the decision and the exact next owner. For a story or offer page, the publishing or distribution worker receives its checked URL, source changes, proof and open issues. Keep that handoff open until acceptance is recorded; the next worker may need to correct a link or return an issue before proceeding.

This task supports the [Content Factory: Produce, Process, Post and Promote](https://localservicespotlight.com/content-factory/). Identity, proof, access or coordination can support several stages. Use the real inputs and receiving owner above; this task does not create unrelated transcripts, clips or ads merely because the diagram has four stages.

## Start with an agent

Give the [AI worker](https://blitzmetrics.com/build-agents/) this recipe, the real inputs, desired result and actions already authorized. Ask for the saved output, sources, checks and next owner. A [skill is a written recipe](https://localservicespotlight.com/plugin/); loading one does not prove account access or perform the task. Use the [installation guide](https://localservicespotlight.com/install/) if reusable setup is needed. A ZIP is a source snapshot, not an access grant or automatic update.

Use the app’s actual supported tools and verified file/account access. Keep a missing human verification step with its real owner. Recurring work needs its own configured job, trigger, timezone and observed result; this guide creates no schedule. Before any media playback, mute the player and set its volume to zero. If silence cannot be verified first, use captions, frames, metadata or another silent check.

## Record the real execution

Open the run record when work begins. Keep one execution ID, starting recipe revision, real inputs and current state. Write the [meta article, the record of this execution](https://blitzmetrics.com/meta-article-prompt/) with actual steps, results, checks, failures and next owner. Writing is required; public release follows existing authority. Link it to this recipe and the [Task Library](https://local-service-spotlight.github.io/task-library/).

Reuse the same execution ID for internal checks, revisions, retries and meta writing. A blocked run stays open with its dependency and owner, without an invented finish time. Dated public examples and distinct verified execution counts remain separate. Propose the smallest source-backed recipe improvement when the actual evidence reveals a defect.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** —
- **Importance:** 3/5 `●●●○○` — frequency 3, revenue 3, gating 2 (supporting)
- **Browse earlier task:** —
- **Browse later task:** —
These are nearby tasks in the library. Use this guide’s Inputs and Handoff sections to choose what comes before and after your work. Catalog order does not establish prerequisites or handoffs.
- **Handoff:** Save this task’s actual output, source, date and checks where the receiving owner can read them. Follow the Inputs and Handoff sections for its next step.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- [Maintained source guide](https://blitzmetrics.com/seo-tree/)
- [This task in the Task Library](https://local-service-spotlight.github.io/task-library/?task=enhance-existing-articles-before-creating-new-ones#task-enhance-existing-articles-before-creating-new-ones)
- [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [Definitive article and task recipe standard](https://blitzmetrics.com/definitive-article-guide/)
- [How recipes and run records fit together](https://localservicespotlight.com/meta-articles/)

## Review and evidence still needed

The inherited contributor status is `complete`. It is preserved, not promoted by this rewrite. That label alone does not prove document readiness, account access, an actual execution or a client result.

The fictional example teaches the method. The checked historical example demonstrates delivered changes, with its missing recipe and handoff evidence stated above. A named semantic reviewer must check the actual opening, full method, sources and handoff. Check the useful opening visual in the normal rendered guide at the current required desktop and mobile sizes, including 1280 × 800 and 390 × 844. Source readability checks do not prove public presentation or task execution.