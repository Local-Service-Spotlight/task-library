---
name: step-4-create-links-with-proper-anchor-text-and-placement
description: "Put useful next steps where readers need them."
category: SEO & Content Architecture
stage: —
definitive_article: /internal-linking
status: complete
---

# Step 4: Create links with proper anchor text and placement

Help readers find the next page they need. Use a checked plan to add clear links that save them time. This is the build step in our [internal-linking process, which turns a page list into checked paths through your site](https://blitzmetrics.com/internal-linking/).

**The path:** Accepted link rows → Fresh source check → Contextual edit → Saved and public readback

**Start when:** Step 3 has supplied accepted source-to-target rows and the exact content edits are authorized.

## Inputs

- [Plan relevant links and orphan repairs](https://local-service-spotlight.github.io/task-library/?task=step-3-identify-money-pages-and-orphan-pages#task-step-3-identify-money-pages-and-orphan-pages) with proposed source, target, anchor, context, owner and relevance.
- Fresh source/body for each page, maintained builder/generator rail, existing media and the expected base revision.
- [Choose the right entity destination](https://local-service-spotlight.github.io/task-library/?task=follow-entity-linking-decision-tree#task-follow-entity-linking-decision-tree) and the baseline request for [Measure the accepted change set](https://local-service-spotlight.github.io/task-library/?task=step-6-measure-and-iterate-with-maa#task-step-6-measure-and-iterate-with-maa) before release, where measurement is planned.

## Steps

1. Open each plan row and fetch the current maintained source before editing. Compare it with the reviewed base and preserve concurrent work. Identify whether a builder, shortcode, generator or ordinary body owns the text; do not replace serialized layout or generated content with a blind full-body write.
2. Read both source and target in context and confirm the planned reader benefit still holds. If the target has changed, redirects to a different subject or does not deliver the proposed promise, hold or revise the row with its owner. A once-approved URL is not a permanent relevance guarantee.
3. Choose concise anchor text that honestly predicts the destination. Prefer three to six descriptive words when natural, or use the actual entity name. Avoid padding, generic “click here,” keyword stuffing and forced phrasing changes that make repeated references less clear.
4. Place the link in the relevant body sentence with enough context to explain why it helps. Useful existing navigation and footers may remain; this task is not a site-wide ban on those links. Add no hidden links or unrelated collections merely to increase the total.
5. Apply [entity linking, choosing the right home for a named person or topic](https://blitzmetrics.com/entity-linking/) to explanations while preserving direct primary evidence and actual account/download actions. Connect stories to their owning methods or offers and add useful cross-links as planned. Keep the source’s factual meaning, relevant proof, IDs and media unchanged outside the exact intended edit.
6. If a suggestion tool proposes additional links, treat them as candidates requiring the same purpose and identity review. Do not accept a batch solely from a keyword score. Log rejected and held rows so the accepted scope does not silently expand during implementation.
7. Save through the supported authorized rail and read back the exact edited field and ordinary rendered page. Follow the real link and check its final target and surrounding sentence. Record source URL, target, anchor, revision, release time and any cache or access gap for QA; a successful API response is only the save stage.

## Definition of done (QA checklist)

Quality assurance (QA) means checking the actual result against its agreed requirements. Follow the [Article Guidelines](https://localservicespotlight.com/article-guidelines/).

- [ ] Every placed link comes from an accepted relevant row and preserves the current source, layout and unrelated content.
- [ ] Anchor meaning, first-mention routing and necessary source/action links remain accurate.
- [ ] Actual saved and normal public links are checked, with held rows and verification gaps explicit.
- [ ] The exact output, source revision, reviewer evidence and remaining owner action are saved.
- [ ] For any reader-facing output, the short grade-five opening states the reader’s useful outcome and supporting method or proof. The body delivers that promise; a useful authentic visual appears in the first screen. Retain exact text and quoted reviewer evidence.

## Example(s)

**Fictional teaching example. This is not a client result or proof of a completed run.**

A fictional approved row links a repair case to its method guide. The live case now has a new photo and paragraph added by its owner. The editor keeps that work, inserts the link in the planned sentence through the existing builder field, and checks the ordinary URL. The receipt records one link, not a replaced article or a proven ranking gain.

## Handoff and Content Factory context

[Check the placed links](https://local-service-spotlight.github.io/task-library/?task=step-5-qa-links-against-google-guidelines#task-step-5-qa-links-against-google-guidelines) receives the exact change log, source revisions and public checks. [Measure the accepted change set](https://local-service-spotlight.github.io/task-library/?task=step-6-measure-and-iterate-with-maa#task-step-6-measure-and-iterate-with-maa) receives the released target list and dates; concurrent-source conflicts remain with the original owner.

This task supports the [Content Factory: Produce, Process, Post and Promote](https://blitzmetrics.com/content-factory/). Identity, proof, access or coordination can support several stages. Use the real inputs and receiving owner above; this task does not create unrelated transcripts, clips or ads merely because the diagram has four stages.

## Start with an agent

Give the [AI worker](https://blitzmetrics.com/build-agents/) this recipe, the real inputs, desired result and actions already authorized. Ask for the saved output, sources, checks and next owner. A [skill is a written recipe](https://localservicespotlight.com/plugin/); loading one does not prove account access or perform the task. Use the [installation guide](https://localservicespotlight.com/install/) if reusable setup is needed. A ZIP is a source snapshot, not an access grant or automatic update.

Use the app’s actual supported tools and verified file/account access. Keep a missing human verification step with its real owner. Recurring work needs its own configured job, trigger, timezone and observed result; this guide creates no schedule. Before any media playback, mute the player and set its volume to zero. If silence cannot be verified first, use captions, frames, metadata or another silent check.

## Record the real execution

Open the run record when work begins. Keep one execution ID, starting recipe revision, real inputs and current state. Write the [meta article, the record of this execution](https://blitzmetrics.com/meta-article-prompt/) with actual steps, results, checks, failures and next owner. Writing is required; public release follows existing authority. Link it to this recipe and the [Task Library](https://local-service-spotlight.github.io/task-library/).

Reuse the same execution ID for internal checks, revisions, retries and meta writing. A blocked run stays open with its dependency and owner, without an invented finish time. Dated public examples and distinct verified execution counts remain separate. Propose the smallest source-backed recipe improvement when the actual evidence reveals a defect.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** —
- **Importance:** 3/5 `●●●○○` — frequency 3, revenue 3, gating 2 (supporting)
- **Browse earlier task:** —
- **Browse later task:** —
These are nearby tasks in the library. Use this guide’s Inputs and Handoff sections to choose what comes before and after your work. Catalog order does not establish prerequisites or handoffs.
- **Handoff:** Save this task’s actual output, source, date and checks where the receiving owner can read them. Follow the Inputs and Handoff sections for its next step.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- [Maintained source guide](https://blitzmetrics.com/internal-linking/)
- [This task in the Task Library](https://local-service-spotlight.github.io/task-library/?task=step-4-create-links-with-proper-anchor-text-and-placement#task-step-4-create-links-with-proper-anchor-text-and-placement)
- [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [Definitive article and task recipe standard](https://blitzmetrics.com/definitive-article-guide/)
- [How recipes and run records fit together](https://localservicespotlight.com/meta-articles/)

### Primary method references

- [Google’s crawlable and descriptive link guidance](https://developers.google.com/search/docs/crawling-indexing/links-crawlable)

## Review and evidence still needed

The inherited contributor status is `complete`. It is preserved, not promoted by this rewrite. That label alone does not prove document readiness, account access, an actual execution or a client result.

The fictional example teaches the method and does not fill a real-run evidence gap. A named semantic reviewer must check the actual opening, full method, sources and handoff. Check the useful opening visual in the normal rendered guide at the current required desktop and mobile sizes, including 1280 × 800 and 390 × 844. Source readability checks do not prove public presentation or task execution.