# Use one guide for one business job

Choose a job, share its guide and your files, then check one result. Open START-HERE.md for the first steps and a prompt to copy.

Library snapshot: September 17, 2026. This archive holds 125 guides. See manifest.json for their paths and contributor status claims. The archive is separate from the curated plugin and does not install or schedule itself.
