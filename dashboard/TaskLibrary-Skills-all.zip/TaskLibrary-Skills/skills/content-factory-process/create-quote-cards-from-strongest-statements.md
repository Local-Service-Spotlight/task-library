---
name: create-quote-cards-from-strongest-statements
description: "Put a true quote on a clear card. Keep the speaker’s words and name easy to read."
category: Content Factory — Process
stage: Process
definitive_article: GAP — to be written
status: needs-work
---

# Create quote cards from strongest statements

A short quote can help a reader remember a good point. This guide turns a real statement into a clear card. Start with the checked words and the person who said them.

**The path:** Checked quote → Real attribution → Readable card → Source-linked export.

**Use this when:** A source has concise, context-safe statements worth turning into attributed graphic assets.

## Inputs
- The verified transcript and original source times, with rights to quote and reuse the material.
- The speaker’s verified full name and relevant company/role, plus a permitted real photo when available.
- The brand’s design rules, actual destination sizes and existing design tool.
- The source/asset tracker and requested number of cards.

## First-run prompt

> Find source-safe exact quotes and prepare the requested cards. Check surrounding context, attribution and image rights. Keep direct quotes verbatim, label summaries, inspect the final export at phone size, and save source timestamps. Do not invent a speaker, image, endorsement or publication.

## Steps
1. Find one- or two-sentence statements that make sense without hidden context. Check the surrounding source for a condition or limitation that must remain.
2. Copy the quote exactly from the checked source and record its time. If it needs paraphrasing, label it a summary and design it without quotation marks; do not quietly rewrite a direct quote.
3. Select the strongest usable set within the request. Three to five is a source planning suggestion, not a reason to invent weak or unsupported quotes.
4. Confirm attribution and permissions. A first name, domain-only praise or unknown speaker is not a publishable testimonial. If the photo is missing, record that need or prepare a clearly identified text layout instead of using a stock face.
5. Set the quote in large, high-contrast type with the real attribution nearby. Use the speaker’s permitted image where supplied and keep the design tied to the statement rather than implying an endorsement beyond it.
6. Size the card for the actual destination and inspect it at phone/thumbnail scale. Keep text clear of crops and platform overlays. Add accessible post text describing the quote rather than relying only on pixels.
7. Compare the final exported words with the transcript, including negatives, numbers and punctuation that changes meaning. Verify that the photo and attribution belong to this speaker.
8. Save the actual file, source time, quote, design version and next use in the tracker. A finished graphic remains a prepared asset until a separate scoped posting task publishes it.

## Definition of done (QA checklist)

- [ ] Every direct quote is exact, source-anchored and context-safe.
- [ ] Name, relevant attribution and photo identity/rights are verified.
- [ ] The final card and accessible companion text are readable and faithful.
- [ ] Actual cards and source links are logged; no fictional card is recorded as a client outcome.

## Example(s)

**Fictional teaching example — the person and quote are invented.** The sample source says, “A photo helps us prepare. It does not replace a close look at the bike.” A teaching card keeps both sentences and attributes them to “Alex, sample Maple Cycle mechanic.”

The shorter line “A photo replaces a close look” is rejected because it reverses the meaning. A sample text-only design is useful for this lesson, but cannot be passed off as a real quote card from a real client. In a real run, replace the fictional text and attribution with checked source evidence.

## Handoff and Content Factory context

The content owner receives the cards for [Prepare platform posts](https://local-service-spotlight.github.io/task-library/?task=create-social-media-posts-per-platform#task-create-social-media-posts-per-platform) or [Add article visuals](https://local-service-spotlight.github.io/task-library/?task=step-8-add-photos-and-featured-image#task-step-8-add-photos-and-featured-image) when the image genuinely supports that page.

Produce supplies the real source. **Process**, this stage of the [Content Factory](https://blitzmetrics.com/content-factory/), turns it into useful finished assets. Post saves or publishes them on the agreed channels. Promote tests and distributes suitable work within its own scope. The handoff above names this task’s actual next step; catalog neighbors alone are not prerequisites.

## When this runs

One card batch per selected source, with duplicate checks against prior assets. Repeat only for a new quote or requested correction.

## First-run setup and continuity

Open the supplied task file and its linked source. Verify the project’s real inputs, account, access and output folder before work. This Markdown file is a guide; it does not install an app, connect an account, supply a subscription or create a schedule. Carry out work already authorized; do not ask for the same approval again. Keep any unsupplied destination or new action outside that scope clearly pending.

Save source IDs, versions, decisions, checked outputs and next owner in the project tracker. Before a retry, check the saved state and other workers’ changes. A model name does not guarantee memory or a running timer. Repeated work needs an actual configured trigger and durable state; one-off work can be started by the prompt above.

Keep agent media muted with volume zero before playback. If mute cannot be verified, use captions, metadata or still frames. State the limit: silent visual checks do not prove spoken-word accuracy or audio quality. Do not start sound through the user’s speakers unless explicitly asked.

## Write up the real run

For every actual attempt, [write its meta article](https://blitzmetrics.com/meta-article-prompt/) with this recipe and revision, trigger, steps performed, output evidence, measured result, gaps and next owner. Failed, blocked and partial attempts also get a written record. A draft can satisfy writing; publishing it follows the existing job scope.

Keep one stable execution ID across retries and edits. A separately scoped child task may have its own ID linked to its parent. Writing the parent’s meta record is part of that run, not an endless new chain. The [recipe and meta-article guide](https://localservicespotlight.com/meta-articles/) explains this distinction. Teaching examples are not real executions and must not enter the run count.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** Process
- **Importance:** 4/5 `●●●●○` — frequency 4, revenue 3, gating 2 (runs every factory cycle or weekly)
- **Suggested previous station:** `extract-15-60-second-clips-from-long-form-video`
- **Suggested next station:** `step-5-write-article-from-transcript`
These stations are generated neighbors, not verified prerequisites or handoffs. Follow the task’s actual Inputs and Handoff sections.
- **Handoff:** Process-stage artifact examples include `transcript.md`, `gct.md`, `article.html` (or a staged draft), `clips/`, or `04-Promote-Creatives/`. These are examples, not requirements for every task. Follow this task's actual Inputs and Handoff sections for the required output, evidence, and next owner. Pass the files or records, not one vendor's memory.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- Dedicated canonical article: not mapped in this source record. Use the maintained owned training below until that article gap is reviewed.
- Exact task: [Create quote cards from strongest statements](https://local-service-spotlight.github.io/task-library/?task=create-quote-cards-from-strongest-statements#task-create-quote-cards-from-strongest-statements)
- Writing standard: [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [Entity linking: choose the right person, company or guide](https://blitzmetrics.com/entity-linking/)

## Review and evidence still needed

The source contributor status is preserved. It is not certification of this draft or proof of account access, completed work or a live outcome. The worked example teaches the method and is explicitly fictional.
- Dedicated article is unmapped; real speaker/source/rights and final graphics require an actual run.