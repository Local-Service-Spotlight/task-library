---
name: ensure-working-contact-form-delivers-notifications
description: "Check that a form sends the right request to the right person. Keep proof from both ends."
category: Digital Plumbing
stage: —
definitive_article: /digital-plumbing
status: needs-work
---

# Ensure Working Contact Form Delivers Notifications

Use this guide to check that a web form sends each request to the right person. It helps you catch lost requests before you send more people to your site. Start with [a clear contact path](https://local-service-spotlight.github.io/task-library/?task=create-clear-conversion-path#task-create-clear-conversion-path), which picks the next step for your visitor.

**The path:** Form input → Accepted request → Team receipt → Follow-up owner.

**Use this when:** a form launches, its plugin or sender changes, or expected website requests are missing.

## Inputs
- The form URLs and IDs, supported form settings access and the approved monitored receiver.
- The actual sending service and current [email authentication setup](https://local-service-spotlight.github.io/task-library/?task=configure-spf-dkim-dmarc-for-deliverability#task-configure-spf-dkim-dmarc-for-deliverability), with access to relevant delivery logs or a named mail owner.
- The authorized test scope, clear test marker, device coverage and expected receipt window. Identify downstream customer-record, booking or automatic-reply actions before submitting.

## Starting state and run record

Start with the supplied form IDs, intended receiver, test marker, approved device scope and receipt window. For each test, record form ID and revision, marker and time, device, accepted or rejected result, matching receiver record and time, delivery delay, downstream effect, issue and next owner. The acceptance measure is a matching request at the approved destination within the agreed window; a success banner or mail-server acceptance alone does not pass. Keep tests separate from real leads and do not turn test counts into sales claims.

## First-run prompt

> Check the supplied forms end to end within the approved test scope. Fix recipient, sender or success-trigger defects at their source. Record the visitor state and actual receiver evidence separately, and keep test records distinct from real leads.

## Steps
1. Map each form to its intended receiver and follow-up team. Read the recipient, From and Reply-To settings plus any customer-system or autoresponder connections. Confirm what a test will trigger so it does not create an unrequested appointment, charge or message chain.
2. Save the current settings and prepare a clearly marked controlled test with no real customer data. Use the supplied receiver and response window; do not substitute an arbitrary personal inbox.
3. Test desktop and mobile paths within that authority. Check required-field errors, accessible labels and submission behavior. Record the form ID, time and test marker, avoiding private data in public evidence.
4. Verify the actual receiving inbox or system entry and delivery time. Inspect junk folders and mail logs when needed. A browser success message or mail-server acceptance is not the same as a message reaching the monitored inbox.
5. For a wrong recipient, update the owning form setting. For sender failure, use the site’s supported authenticated mail or provider integration and its verified domain setup. Use an owned sender address and an appropriate Reply-To; do not spoof the visitor’s address as the authenticated From identity.
6. Ensure success is shown only after the form accepts the intended request, and that errors give a useful next step. If analytics is in scope, trigger the agreed successful-submission event at that point, not merely on a button click.
7. Re-test the affected chain after each fix. Inspect actual received analytics events when included, honoring consent. A Meta Lead event applies only where its meaning and current setup match the real action; installing tracking is not mandatory to prove email delivery.
8. Save the paired visitor and receiver evidence, configured destination and next owner. Mark controlled test entries according to the system’s established process so they do not inflate lead reports; do not delete records blindly.

## Definition of done (QA checklist)

- [ ] Desktop and mobile form behavior was checked for the declared form set.
- [ ] Each accepted test has a matching receipt at the approved monitored destination within the stated window.
- [ ] Sender, recipient and Reply-To behavior are correct and authenticated where required.
- [ ] Success and optional tracking follow actual accepted submissions, with no duplicate event or false lead claim.
- [ ] Test records, downstream effects, remaining gaps and response owner are documented.

## Example(s)

**Fictional teaching example.** A quote form shows “Thanks,” but its notification still goes to a retired mailbox. The lesson updates the recipient to the business’s monitored queue and sends a marked test under a supplied test scope. The mock record pairs form TEST-01 at 10:00 with a receiver entry at 10:01. A second phone test has its own marker. Two received tests prove the lesson path, not two customer leads.

## Handoff and Content Factory context

Hand the paired form and receiver records to the named mail or lead-response owner. The handoff is accepted when that owner confirms the monitored destination and response responsibility for the tested forms; otherwise record acceptance as pending. Use [configure spf dkim dmarc for deliverability](https://local-service-spotlight.github.io/task-library/?task=configure-spf-dkim-dmarc-for-deliverability#task-configure-spf-dkim-dmarc-for-deliverability) for authentication defects or [create clear conversion path](https://local-service-spotlight.github.io/task-library/?task=create-clear-conversion-path#task-create-clear-conversion-path) when the path itself is confusing.

This is a setup check for **Post** in the [Content Factory](https://blitzmetrics.com/content-factory/), the process that turns real stories into useful content. A published page needs a working way for a reader to reach the business. Check that path before **Promote** sends more people to it. Promotion, spend and customer follow-up remain separately scoped work.

## When this runs

Run on setup and after form, mail or plugin changes. The source proposes a quarterly re-test; use that only when adopted in the project’s actual maintenance schedule with a safe test scope and monitored owner.

## First-run setup and continuity

Open the supplied task file and its linked source. Verify the project’s real inputs, account, access and output folder before work. This Markdown file is a guide; it does not install an app, connect an account, supply a subscription or create a schedule. Carry out work already authorized; do not ask for the same approval again. Keep any unsupplied destination or new action outside that scope clearly pending.

Save source IDs, versions, decisions, checked outputs and next owner in the project tracker. Before a retry, check the saved state and other workers’ changes. A model name does not guarantee memory or a running timer. Repeated work needs an actual configured trigger and durable state; one-off work can be started by the prompt above.

Keep agent media muted with volume zero before playback. If mute cannot be verified, use captions, metadata or still frames. State the limit: silent visual checks do not prove spoken-word accuracy or audio quality. Do not start sound through the user’s speakers unless explicitly asked.

## Write up the real run

For every actual attempt, [write its meta article](https://blitzmetrics.com/meta-article-prompt/) with this recipe and revision, trigger, steps performed, output evidence, measured result, gaps and next owner. Failed, blocked and partial attempts also get a written record. A draft can satisfy writing; publishing it follows the existing job scope.

Keep one stable execution ID across retries and edits. A separately scoped child task may have its own ID linked to its parent. Writing the parent’s meta record is part of that run, not an endless new chain. The [recipe and meta-article guide](https://localservicespotlight.com/meta-articles/) explains this distinction. Teaching examples are not real executions and must not enter the run count.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** Gate
- **Importance:** 5/5 `●●●●●` — frequency 4, revenue 5, gating 5 (runs every factory cycle or weekly; ads/revenue path; unblocks a chain (access/plumbing))
- **Suggested previous station:** `ensure-robots-meta-not-blocking-indexing`
- **Suggested next station:** `create-clear-conversion-path`
These stations are generated neighbors, not verified prerequisites or handoffs. Follow the task’s actual Inputs and Handoff sections.
- **Handoff:** Record only the property IDs, access and checks required by this task in the client register. Pass the verified result to the task that needs it.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- Canonical article: https://blitzmetrics.com/digital-plumbing
- Exact task: [Ensure Working Contact Form Delivers Notifications](https://local-service-spotlight.github.io/task-library/?task=ensure-working-contact-form-delivers-notifications#task-ensure-working-contact-form-delivers-notifications)
- Writing standard: [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [Digital Plumbing training](https://blitzmetrics.com/digital-plumbing/)
- [Google Workspace DKIM setup](https://knowledge.workspace.google.com/admin/security/set-up-dkim)
- [Google Analytics DebugView](https://support.google.com/analytics/answer/7201382?hl=en)

## Review and evidence still needed

The source contributor status is preserved. It is not certification of this draft or proof of account access, completed work or a live outcome. The worked example teaches the method and is explicitly fictional.
- Real receiver evidence and authorized downstream test effects must be supplied; this authoring pass submitted no form or message.