---
name: place-content-on-seo-tree-with-proper-links
description: "Give each page a clear home on your site. Add useful links to its main guide and related pages."
category: Content Factory — Post
stage: Post
definitive_article: /seo-tree
status: complete
---

# Place content on SEO Tree with proper links

A useful page can still be hard to find. This guide helps you connect it to the main topic and the next thing a reader needs. Start with the [SEO Tree topic map](https://blitzmetrics.com/seo-tree/) to find the page that already owns that topic.

**The path:** Page’s purpose → Main topic owner → Useful links both ways → Checked map.

**Use this when:** A new or existing piece needs a clear place in the site’s topic map.

## Inputs
- The draft or existing canonical URL and its purpose: task guide, topic hub, story, or record of one run.
- The current [SEO Tree](https://blitzmetrics.com/seo-tree/) map and content inventory, with the agreed main page for each topic.
- The [Goals, Content, and Targeting](https://blitzmetrics.com/gct-business-strategy/) brief: the result wanted, the content used, and who it serves.
- Access and scope for the page and any related pages to be changed. Record an inbound-link handoff if another site owner must add it.

## First-run prompt

> Use my page, current site map, and authorized edit scope to find its real topic owner. Propose useful links in both directions, read the targets, and check named anchors. Make the already-authorized changes and verify them. Record any inbound edit another owner must make; do not invent a hub or claim a pending link is live.

## Steps
1. Read the piece and classify its role. A specific story or answer usually supports a broader guide; a guide may own a repeatable task. Do not mark a story definitive just because it has links.
2. Search the site inventory for an existing page that already answers the same main need. Enhance the canonical page when appropriate. Record why a distinct supporting page is needed rather than silently making a rival hub.
3. Choose the actual parent topic and any useful next guide. Read the target pages. Resolve each target to its final canonical URL; do not build new body links to a redirecting alias. A category or plugin suggestion is a clue, not proof of the right relationship.
4. Add a body link from the specific piece to its main topic or task guide where the reader needs the explanation. Use descriptive words that match the destination. Add related links only when they help a real next question.
5. Follow the [entity-linking guide](https://blitzmetrics.com/entity-linking/): use verified identity pages for people and managed brands, owned explainers for methods and tools, and precise primary sources when they substantiate a claim or needed action. Do not invent a person’s domain.
6. Add a relevant link from the parent or a suitable existing supporting page to the new piece within the authorized edit scope. Do not publish an inbound link from a live page to a private or unpublished target; stage that edit until target visibility is checked. If the edit is outside scope, give the responsible owner the exact sentence, target, and reason; keep inbound placement pending.
7. Save through the site’s supported source. Check each final destination and any fragment after #. Confirm the live body links when publication is in scope; draft links remain draft-only checks.
8. Update the inventory with this page’s role, primary parent, actual inbound source, links, and checked date. If no parent fits, state whether the content or map needs a decision rather than inventing a branch.

## Definition of done (QA checklist)

- [ ] The role and primary topic owner are stated and source-grounded.
- [ ] A useful upward body link reaches the final canonical URL for the correct main explanation.
- [ ] At least one real relevant inbound path is saved and verified, or its exact pending owner/action is stated; no live source exposes a private target.
- [ ] New links and named anchors reach the intended content; no unsupported duplicate hub or redirect alias was made.
- [ ] The inventory records the actual placement and verification state.

If a required inbound edit is pending, report a partial placement with its owner and next action. Do not call that result fully connected.

## Example(s)

**Fictional teaching example — no site was edited.** Maple Cycle has a main “Repair quotes” guide and a smaller story, “What happened when a photo missed the bent part.”

The story links up with “how our repair quotes work.” The guide links down with “a quote changed after inspection” beside the section explaining why photos are only a starting point. A booking page is linked where the reader is ready to arrange a visit.

The sample map is `Repair quotes guide ↔ inspection story → booking step`. It does not link every page to every other page. If the guide’s editor has not yet saved the inbound link, the story’s inventory row says “upward link checked; inbound edit pending,” not “fully connected.”

### Checked historical example — limited navigation acceptance

The [Western Trading Post collector directory](https://westerntradingpost.com/collector-guides/) connects readers to five maker guides and related shopping and selling pages. In October 2026, the recipient accepted the dropdown menus, clickable directory and native BigCommerce text/link editing. This is one delivery, not six separate runs.

The recorded check found no upward directory links in the five guide bodies. The original recipe revision and full link inventory were not recovered. This example proves the named navigation features and recipient-confirmed editability; it does not prove every present checklist item, current recipe use, new-user success or search/revenue gains.

## Handoff and Content Factory context

The publisher receives the page placement and link evidence, then runs [Check the full article checklist](https://local-service-spotlight.github.io/task-library/?task=verify-all-items-on-blog-posting-checklist#task-verify-all-items-on-blog-posting-checklist). A different page owner gets only the specific pending inbound edit when needed.

This task serves **Post** in the [Content Factory](https://localservicespotlight.com/content-factory/). Produce supplies the source, Process prepares it, Post places and checks it on the agreed channels, and Promote distributes proven work under its own scope. The task’s actual handoff above defines the next step; list order alone does not create a prerequisite.

## When this runs

Run for each new page or a defined repair to an existing page. Repeat when the role, parent, or linked targets change. No automated site-wide link job is created.

## First-run setup and continuity

Use the exact account, source, destination and authority recorded for the job. Carry out publication, messages or repairs already authorized once their required checks pass; do not ask for the same approval again. If an action is outside that scope, finish the authorized work and state the specific remaining need. A login, plugin, or task file does not itself grant new authority.

Keep the latest state, record IDs, revisions and next owner in the project tracker or files. Before a retry, check the current saved/sent/published item to avoid duplicates or overwriting another edit. A model has no guaranteed memory, scheduler or account access just because it is called persistent. A future check needs a configured timer or a named person.

Keep all agent media previews muted with volume zero before playback. If this cannot be verified, use captions, metadata or still frames and state what was not tested. No first-load autoplay is part of these page instructions.

## Write up the real run

For each actual attempt, [write its meta article](https://blitzmetrics.com/meta-article-prompt/) with this exact task, source revision, trigger, work, decisions, evidence, result and next owner. Failed, partial and blocked attempts still get a written record. A private draft is a valid writing outcome; public publication follows the existing scope.

Keep one stable execution ID for the actual task run. Retries, checks and changed artifacts do not add runs. A separately scoped child task may have its own ID linked to its parent; writing the parent’s meta record is part of that same run. The [recipe and meta-article guide](https://localservicespotlight.com/meta-articles/) explains the distinction. Teaching examples below or above are not execution evidence and must not enter the run count.


<!-- factory-layer:start -->

## Factory chain (do not treat this as isolated)

- **Phase:** Post
- **Importance:** 5/5 `●●●●●` — frequency 5, revenue 4, gating 3 (runs every factory cycle or weekly; creates the asset ads amplify)
- **Browse earlier task:** `step-14b-run-linkwhisper-for-internal-links`
- **Browse later task:** `step-17-final-formatting-and-qa-checks`
These are nearby tasks in the library. Use this guide’s Inputs and Handoff sections to choose what comes before and after your work. Catalog order does not establish prerequisites or handoffs.
- **Handoff:** Draft URL or WP post ID, slug, author user ID, featured-image media ID. Promote reads the live URL, not the draft.

## Model routing (same factory, any engine)

- **This task's lane:** `any` — Any capable chat model (Claude, ChatGPT, Grok, Gemini). SOP following, drafts, checklists.
- **Single-engine path:** Use the capable AI app you already have. Check its required tools and access before starting. Pass the actual result and proof to the next task.
- **Optional multi-engine:** A tested local model may draft; a stronger model may review facts and voice. Use supported tools for approved actions. Pick models from observed quality and cost; a model name does not prove it can run this task.
- **Never** store the working state in one vendor's memory. Files in the Content Library are the bridge.

<!-- factory-layer:end -->
## Definitive article & links

- Canonical article: https://blitzmetrics.com/seo-tree/
- Exact Task Library record: [Place content on SEO Tree with proper links](https://local-service-spotlight.github.io/task-library/?task=place-content-on-seo-tree-with-proper-links#task-place-content-on-seo-tree-with-proper-links)
- Working writing standard: [Article Guidelines](https://localservicespotlight.com/article-guidelines/)
- [SEO Tree: give a page its right topic home](https://blitzmetrics.com/seo-tree/)
- [Entity linking: choose the right person, company or guide](https://blitzmetrics.com/entity-linking/)

## Review and evidence still needed

The original contributor status in the header is preserved. It does not certify this proposed rewrite or prove that this account, publication, message, player or check has run. The Maple Cycle teaching example is fictional. The checked historical collector example supports only its named navigation and recipient-confirmed editing scope. Current-recipe execution and new-user use still need their own evidence.
- The live site map and authorized inbound source edits must be verified for the real page.